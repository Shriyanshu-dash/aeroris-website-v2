const visualElementStore = new WeakMap();

export { visualElementStore };
//# sourceMappingURL=store.mjs.map
