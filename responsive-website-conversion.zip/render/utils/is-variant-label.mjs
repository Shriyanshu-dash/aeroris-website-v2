/**
 * Decides if the supplied variable is variant label
 */
function isVariantLabel(v) {
    return typeof v === "string" || Array.isArray(v);
}

export { isVariantLabel };
//# sourceMappingURL=is-variant-label.mjs.map
