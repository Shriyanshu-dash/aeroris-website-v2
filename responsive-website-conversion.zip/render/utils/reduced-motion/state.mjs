// Does this device prefer reduced motion? Returns `null` server-side.
const prefersReducedMotion = { current: null };
const hasReducedMotionListener = { current: false };

export { hasReducedMotionListener, prefersReducedMotion };
//# sourceMappingURL=state.mjs.map
