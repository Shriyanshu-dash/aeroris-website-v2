const isKeyframesTarget = (v) => {
    return Array.isArray(v);
};

export { isKeyframesTarget };
//# sourceMappingURL=is-keyframes-target.mjs.map
