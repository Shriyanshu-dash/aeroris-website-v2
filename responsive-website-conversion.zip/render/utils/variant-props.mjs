const variantPriorityOrder = [
    "animate",
    "whileInView",
    "whileFocus",
    "whileHover",
    "whileTap",
    "whileDrag",
    "exit",
];
const variantProps = ["initial", ...variantPriorityOrder];

export { variantPriorityOrder, variantProps };
//# sourceMappingURL=variant-props.mjs.map
