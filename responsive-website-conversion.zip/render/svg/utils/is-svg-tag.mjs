const isSVGTag = (tag) => typeof tag === "string" && tag.toLowerCase() === "svg";

export { isSVGTag };
//# sourceMappingURL=is-svg-tag.mjs.map
