const isCSSVar = (name) => name.startsWith("--");

export { isCSSVar };
//# sourceMappingURL=is-css-var.mjs.map
