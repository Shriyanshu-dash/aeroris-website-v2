function makeAnimationInstant(options) {
    options.duration = 0;
    options.type = "keyframes";
}

export { makeAnimationInstant };
//# sourceMappingURL=make-animation-instant.mjs.map
