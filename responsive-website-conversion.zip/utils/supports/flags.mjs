/**
 * Add the ability for test suites to manually set support flags
 * to better test more environments.
 */
const supportsFlags = {};

export { supportsFlags };
//# sourceMappingURL=flags.mjs.map
