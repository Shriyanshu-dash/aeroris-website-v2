import { fillOffset } from './fill.mjs';

function defaultOffset(arr) {
    const offset = [0];
    fillOffset(offset, arr.length - 1);
    return offset;
}

export { defaultOffset };
//# sourceMappingURL=default.mjs.map
