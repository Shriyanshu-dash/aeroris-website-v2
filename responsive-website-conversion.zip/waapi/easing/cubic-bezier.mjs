const cubicBezierAsString = ([a, b, c, d]) => `cubic-bezier(${a}, ${b}, ${c}, ${d})`;

export { cubicBezierAsString };
//# sourceMappingURL=cubic-bezier.mjs.map
