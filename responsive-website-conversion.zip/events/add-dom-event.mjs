function addDomEvent(target, eventName, handler, options = { passive: true }) {
    target.addEventListener(eventName, handler, options);
    return () => target.removeEventListener(eventName, handler);
}

export { addDomEvent };
//# sourceMappingURL=add-dom-event.mjs.map
