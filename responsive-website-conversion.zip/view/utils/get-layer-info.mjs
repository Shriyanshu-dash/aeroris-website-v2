function getViewAnimationLayerInfo(pseudoElement) {
    const match = pseudoElement.match(/::view-transition-(old|new|group|image-pair)\((.*?)\)/);
    if (!match)
        return null;
    return { layer: match[2], type: match[1] };
}

export { getViewAnimationLayerInfo };
//# sourceMappingURL=get-layer-info.mjs.map
