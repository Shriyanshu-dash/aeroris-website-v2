import { isMotionValue } from '../utils/is-motion-value.mjs';

function isWillChangeMotionValue(value) {
    return Boolean(isMotionValue(value) && value.add);
}

export { isWillChangeMotionValue };
//# sourceMappingURL=is.mjs.map
