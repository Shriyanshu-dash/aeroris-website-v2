const isMotionValue = (value) => Boolean(value && value.getVelocity);

export { isMotionValue };
//# sourceMappingURL=is-motion-value.mjs.map
