/**
 * ValueType for "auto"
 */
const auto = {
    test: (v) => v === "auto",
    parse: (v) => v,
};

export { auto };
//# sourceMappingURL=auto.mjs.map
