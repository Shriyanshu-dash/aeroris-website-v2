const floatRegex = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;

export { floatRegex };
//# sourceMappingURL=float-regex.mjs.map
