/**
 * Provided a value and a ValueType, returns the value as that value type.
 */
const getValueAsType = (value, type) => {
    return type && typeof value === "number"
        ? type.transform(value)
        : value;
};

export { getValueAsType };
//# sourceMappingURL=get-as-type.mjs.map
