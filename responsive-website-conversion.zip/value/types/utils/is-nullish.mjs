function isNullish(v) {
    return v == null;
}

export { isNullish };
//# sourceMappingURL=is-nullish.mjs.map
