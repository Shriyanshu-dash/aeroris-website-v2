import { number } from './numbers/index.mjs';

const int = {
    ...number,
    transform: Math.round,
};

export { int };
//# sourceMappingURL=int.mjs.map
