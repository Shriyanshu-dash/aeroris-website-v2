const activeAnimations = {
    layout: 0,
    mainThread: 0,
    waapi: 0,
};

export { activeAnimations };
//# sourceMappingURL=animation-count.mjs.map
