const statsBuffer = {
    value: null,
    addProjectionMetrics: null,
};

export { statsBuffer };
//# sourceMappingURL=buffer.mjs.map
