const isDragging = {
    x: false,
    y: false,
};
function isDragActive() {
    return isDragging.x || isDragging.y;
}

export { isDragActive, isDragging };
//# sourceMappingURL=is-active.mjs.map
