const isPressing = new WeakSet();

export { isPressing };
//# sourceMappingURL=state.mjs.map
